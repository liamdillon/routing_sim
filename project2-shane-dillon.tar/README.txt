1. Robert Joseph Shane, James Liam Dillon
2. At one point code relied on copying a dictionaries which turned out to be pass by reference was very confusing. Also needed to manage time better.
3. Path Vector protocol would have solved  the count to infinity problem completely rather than a incomplete solution like Poison Reverse
4. None
